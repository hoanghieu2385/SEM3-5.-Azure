using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClassFunction.DTOs
{
    public class AddClassDTO
    {
        public string? ClassName { get; set; }
        public string? RoomName { get; set; }
    }
}